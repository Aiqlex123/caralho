#pragma once

enum HitscanMode : int {
	NORMAL  = 0,
	LETHAL  = 1,
	LETHAL2 = 3,
	PREFER  = 4
};

struct AnimationBackup_t {
	vec3_t           m_origin, m_abs_origin;
	vec3_t           m_velocity, m_abs_velocity;
	int              m_flags, m_eflags;
	float            m_duck, m_body;
	C_AnimationLayer m_layers[ 13 ];
};

struct HitscanData_t {
	float  m_damage;
	vec3_t m_pos;

	__forceinline HitscanData_t( ) : m_damage{ 0.f }, m_pos{} {}
};

struct HitscanBox_t {
	int         m_index;
	HitscanMode m_mode;

	__forceinline bool operator==( const HitscanBox_t& c ) const {
		return m_index == c.m_index && m_mode == c.m_mode;
	}
};

class AimPlayer {
public:
	using records_t = std::deque< std::shared_ptr< LagRecord > >;
	using hitboxcan_t = stdpp::unique_vector< HitscanBox_t >;

public:
	// essential data.
	Player* m_player;
	float	  m_spawn;
	float     m_last_reliable_pitch;
	int m_ticks_since_dormant;
	int m_unknown_move;
	records_t m_records;
	float      m_best_yaw;


	float m_old_sim;
	float m_cur_sim;
	float m_sim_rate;
	float m_sim_cycle;

	// aimbot data.
	hitboxcan_t m_hitboxes;
	bool        m_prefer_body;
	bool        m_prefer_head;
	vec3_t      m_pos{};
	LagRecord m_walk_record;

	// resolve data.
	int       m_shots;
	int       m_missed_shots;
	int       m_test_index;

	float     m_body_update;
	bool      m_moved;
	bool m_has_updated;
	bool m_was_22;

	float m_flCycle;
	float m_flPlaybackRate;

	int m_edge_index;
	int m_logic_index;
	int m_reversefs_index;
	int m_fam_reverse_index;
	bool m_should_correct;
	int m_testfs_index;
	int m_spin_index;
	float m_last_angle;
	int m_reversefs_at_index;
	int m_stand3_reversefs;
	int m_stand3_back;
	int m_airlast_index;
	int m_air_index;
	int m_airlby_index;
	int m_airback_index;
	int m_back_index;
	bool  m_predict;
	int m_back_at_index;
	int m_lastmove_index;
	int m_sidelast_index;
	int m_lby_index;
	float update_body;
	int m_lowlby_index;
	bool valid_flick;
	int m_lbyticks;
	bool m_broke_lby;
	bool m_has_body_updated;
	bool ever_flicked;
	int m_stand_index1;
	int m_stand_index2;
	float m_fakeflick_body;
	int m_stand_index3;
	int m_stand_index4;
	int m_body_index;
	int m_fakewalk_index;
	int m_moving_index;

	// data about the LBY proxy.
	float m_body;
	float m_old_body;
	float m_anti_fs_angle;
	bool freestand_data;
	bool is_last_moving_lby_valid;
	bool is_air_previous_valid;
	float m_valid_pitch;

	float m_stored_body;
	float m_stored_body_old;

	float m_body_proxy;
	float m_body_proxy_old;
	bool  m_body_proxy_updated;

	float m_moving_time;
	float m_moving_body;
	vec3_t m_moving_origin;
	std::deque< float > m_lby_updates;


	// networking stuff
	float m_networked_angle = 1337.f;
	bool  m_is_kaaba = false;
	bool  m_is_cheese_crack = false;
	bool  m_is_candyhook = false;
	bool  m_is_dopium = false;
	bool  m_is_robertpaste = false;
	bool  m_is_fade = false;
	bool  m_is_godhook = false;
	int   m_network_index;



	float m_alive_loop_cycle;
	C_LagRecord backup_record = {};
public:
	void UpdateAnimations( LagRecord* record );
	void OnNetUpdate( Player* player );

	void OnRoundStart( Player* player );
	void SetupHitboxes( LagRecord* record, bool history );
	bool SetupHitboxPoints( LagRecord* record, BoneArray* bones, int index, std::vector< vec3_t >& points );
	bool GetBestAimPosition( vec3_t& aim, float& damage, LagRecord* record );

public:
	void reset( ) {
		m_player       = nullptr;
		m_spawn        = 0.f;
		m_walk_record  = LagRecord{};
		m_shots        = 0;
		m_missed_shots = 0;

		m_is_kaaba = false;
		m_is_cheese_crack = false;
		m_is_candyhook = false;
		m_is_dopium = false;
		m_is_robertpaste = false;
		m_is_fade = false;
		m_predict = false;

		m_records.clear( );
		m_hitboxes.clear( );
	}
};

class Aimbot {
private:
	struct target_t {
		Player*    m_player;
		AimPlayer* m_data;
	};

	struct knife_target_t {
		target_t  m_target;
		LagRecord m_record;
	};

	struct table_t {
		uint8_t swing[ 2 ][ 2 ][ 2 ]; // [ first ][ armor ][ back ]
		uint8_t stab[ 2 ][ 2 ];		  // [ armor ][ back ]
	};

	const table_t m_knife_dmg{ { { { 25, 90 }, { 21, 76 } }, { { 40, 90 }, { 34, 76 } } }, { { 65, 180 }, { 55, 153 } } };

	std::array< ang_t, 12 > m_knife_ang{
		ang_t{ 0.f, 0.f, 0.f }, ang_t{ 0.f, -90.f, 0.f }, ang_t{ 0.f, 90.f, 0.f }, ang_t{ 0.f, 180.f, 0.f },
		ang_t{ -80.f, 0.f, 0.f }, ang_t{ -80.f, -90.f, 0.f }, ang_t{ -80.f, 90.f, 0.f }, ang_t{ -80.f, 180.f, 0.f },
		ang_t{ 80.f, 0.f, 0.f }, ang_t{ 80.f, -90.f, 0.f }, ang_t{ 80.f, 90.f, 0.f }, ang_t{ 80.f, 180.f, 0.f }
	};

public:
	std::array< AimPlayer, 64 > m_players;
	std::vector< AimPlayer* >   m_targets;

	BackupRecord m_backup[ 64 ];

	// target selection stuff.
	float m_best_dist;
	float m_best_fov;
	float m_best_damage;
	int   m_best_hp;
	float m_best_lag;
	float m_best_height;
	
	// found target stuff.
	Player*    m_target;
	ang_t      m_angle;
	vec3_t     m_aim;
	int        m_hitbox, m_hitgroup, m_awall_hitbox;
	float      m_damage;
	LagRecord* m_record;

	// fake latency stuff.
	bool       m_fake_latency;
	bool	   m_damage_toggle;
	bool	   m_force_body;
	bool m_stop;

	bool dt_aim;

public:
	__forceinline void reset( ) {
		// reset aimbot data.
		init( );

		// reset all players data.
		for( auto& p : m_players )
			p.reset( );
	}

	__forceinline bool IsValidTarget( Player* player ) {
		if( !player )
			return false;

		if( !player->IsPlayer( ) )
			return false;

		if( !player->alive( ) )
			return false;

		if( player->m_bIsLocalPlayer( ) )
			return false;

		if( !player->enemy( g_cl.m_local ) )
			return false;

		return true;
	}

public:
	// aimbot.
	void init( );
	void StripAttack( );
	void think( );
	void find( );
	bool CheckHitchance( Player* player, const ang_t& angle );
	bool CanHitPlayer(LagRecord* pRecord, const vec3_t& vecEyePos, const vec3_t& vecEnd, int iHitboxIndex);
	bool SelectTarget( LagRecord* record, const vec3_t& aim, float damage );
	void apply( );
	void NoSpread( );

	// knifebot.
	void knife( );
	bool CanKnife( LagRecord* record, ang_t angle, bool& stab );
	bool KnifeTrace( vec3_t dir, bool stab, CGameTrace* trace );
	bool KnifeIsBehind( LagRecord* record );
};

extern Aimbot g_aimbot;